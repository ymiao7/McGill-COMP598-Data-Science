"""
This script contains the main function for unit tests
"""




import unittest

from .tests.func import *

if __name__ == '__main__':
    unittest.main()
